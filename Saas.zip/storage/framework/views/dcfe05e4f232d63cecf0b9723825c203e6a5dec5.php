

<?php $__env->startSection("content"); ?>
    <div class="container-fluid">
        <router-view :key="$route.fullPath"></router-view>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp81\htdocs\order\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>