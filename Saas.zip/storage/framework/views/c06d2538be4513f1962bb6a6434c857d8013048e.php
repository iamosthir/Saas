<?php $__env->startSection("content"); ?>
    <div class="container">
        <router-view :key="$route.fullPath"></router-view>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mdeas\OneDrive\Desktop\Saas\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>