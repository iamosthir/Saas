<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin Panel Login</title>
    <!-- Font Awesome -->
    <link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet"/>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"/>
    
    <link rel="stylesheet" href="<?php echo e(asset("css/mdb.rtl.min.css")); ?>">
    
    
    <link rel="stylesheet" href="<?php echo e(asset("css/app.css")); ?>">
    
</head>
<body>
    <section class="login-section">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-5 col-lg-4">
            <div class="card login-card">
              <div class="card-body">
                <h5 class="card-title text-center"><strong>USER LOGIN <i class="fas fa-user"></i></strong></h5>
                <form class="mt-5" action="<?php echo e(route('login')); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <div class="form-outline mb-5">
                    <input type="email" id="formEmail" class="form-control-lg form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                     name="email" placeholder="Provide your valid email..." value="<?php echo e(old('email')); ?>"/>
                    <label class="form-label" for="formEmail">Email</label>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>

                  <div class="form-outline mb-2">
                    <input type="password" id="formPass" class="form-control-lg form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                    name="password" placeholder="Enter your password..."/>
                    <label class="form-label" for="formPass">Password</label>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>

                  <div class="form-check mb-5">
                    <input class="form-check-input" type="checkbox" value="" id="rememberMe" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>/>
                    <label class="form-check-label" for="rememberMe">Remember Me</label>
                  </div>

                  <div class="form-group mb-3">
                    <button class="btn btn-primary" type="submit">Login</button>
                  </div>


                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <link rel="stylesheet" href="<?php echo e(asset("js/app.js")); ?>">
    <!-- MDB -->
    <script type="text/javascript" src="<?php echo e(asset("js/mdb.min.js")); ?>"></script>
</body>
</html><?php /**PATH /home/wholesaleteknoiq/public_html/resources/views/pages/login.blade.php ENDPATH**/ ?>