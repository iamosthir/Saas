<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>فاتورة البيع #<?php echo e($invoice->id); ?></title>
    <meta name="viewport" content="width=700, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <style>
        body {
            background: #f5f6fa;
            color: #222;
            font-family: 'Tahoma', Arial, sans-serif;
            padding: 30px 0;
        }
        .invoice-box {
            background: #fff;
            max-width: 700px;
            margin: 0 auto;
            border-radius: 12px;
            box-shadow: 0 2px 8px #ddd;
            padding: 32px 28px 28px 28px;
            border: 1.5px solid #dedede;
        }
        .invoice-logo {
            max-width: 120px;
            margin-bottom: 10px;
        }
        .invoice-header {
            text-align: center;
            margin-bottom: 28px;
        }
        .invoice-title {
            font-size: 2.2rem;
            font-weight: bold;
            color: #355c7d;
            margin-bottom: 7px;
        }
        .table th, .table td {
            vertical-align: middle !important;
        }
        .table th {
            background: #f2f3f8;
        }
        .table tbody tr:last-child td {
            border-bottom: 2px solid #355c7d;
        }
        .summary-row td {
            font-size: 1.2rem;
            font-weight: bold;
            background: #f9fafc;
        }
        .sign-area {
            margin-top: 48px;
            font-size: 1.15rem;
        }
        .company-info {
            text-align: left;
            color: #888;
            font-size: 0.95rem;
        }
        @media print {
            body {
                background: #fff !important;
                padding: 0 !important;
            }
            .invoice-box {
                box-shadow: none !important;
                border: none !important;
                padding: 10px !important;
            }
            .no-print { display: none !important; }
        }
    </style>
    <script>
        window.onload = function() { window.print(); }
    </script>
</head>
<body>
<div class="invoice-box" id="printable-invoice">

    <div class="invoice-header">
        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Company Logo" class="invoice-logo">
        <div class="company-info mt-2 mb-2">
            <strong>اسم الشركة:</strong> شركتك الحديثة<br>
            <strong>العنوان:</strong> بغداد، العراق<br>
            <strong>الهاتف:</strong> 0770-000-0000
        </div>
        <div class="invoice-title">فاتورة بيع</div>
        <div class="text-muted fs-6">رقم الفاتورة: <b><?php echo e($invoice->id); ?></b></div>
    </div>

    <div class="mb-3">
        <div><b>العميل:</b> <?php echo e($invoice->customer->customer_name ?? ''); ?></div>
        <div><b>رقم الهاتف:</b> <?php echo e($invoice->customer->phone1 ?? ''); ?></div>
        <div><b>التاريخ:</b> <?php echo e(\Carbon\Carbon::parse($invoice->created_at)->format('Y-m-d H:i')); ?></div>
        <?php if($invoice->note): ?>
        <div><b>ملاحظة:</b> <?php echo e($invoice->note); ?></div>
        <?php endif; ?>
    </div>

    <table class="table table-bordered table-striped align-middle mb-4">
        <thead>
            <tr>
                <th>#</th>
                <th>المنتج</th>
                <th>المتغير</th>
                <th>العدد</th>
                <th>سعر الوحدة</th>
                <th>الإجمالي</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $products = is_array($invoice->products) ? $invoice->products : json_decode($invoice->products, true) ?? [];
            ?>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i+1); ?></td>
                    <td><?php echo e($item['product_name'] ?? ''); ?></td>
                    <td><?php echo e($item['variant_name'] ?? ''); ?></td>
                    <td><?php echo e($item['qnt']); ?></td>
                    <td><?php echo e(number_format($item['unit_price'] ?? 0, 0)); ?> د.ع</td>
                    <td><?php echo e(number_format($item['total_price'] ?? 0, 0)); ?> د.ع</td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr class="summary-row">
                <td colspan="5" class="text-end"><b>الإجمالي الكلي</b></td>
                <td><b><?php echo e(number_format($invoice->total_price, 0)); ?> د.ع</b></td>
            </tr>
        </tbody>
    </table>

    <div class="row mt-4">
        <div class="col-6">
            <div><b>حالة الدفع:</b> 
                <span style="color:<?php echo e($invoice->payment_status === 'paid' ? '#17a673' : '#d33'); ?>">
                    <?php echo e($invoice->payment_status === 'paid' ? 'مدفوع' : ($invoice->payment_status === 'pending' ? 'قيد الانتظار' : 'مدفوع جزئيا')); ?>

                </span>
            </div>
        </div>
        <div class="col-6 text-end">
            <div><b>حالة الطلب:</b> 
                <span class="badge bg-info text-dark"><?php echo e($invoice->order_status); ?></span>
            </div>
        </div>
    </div>

    <div class="sign-area mt-5">
        التوقيع: _________________________
    </div>

    <div class="text-center mt-4 no-print">
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">رجوع</a>
        <button class="btn btn-primary" onclick="window.print();"><i class="fas fa-print"></i> طباعة</button>
    </div>

</div>
</body>
</html>
<?php /**PATH /home/wholesaleteknoiq/public_html/resources/views/pages/sales-print-invoice.blade.php ENDPATH**/ ?>