<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Dashboard</title>
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet"/>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"/>
    
    <link rel="stylesheet" href="<?php echo e(asset("css/mdb.rtl.min.css")); ?>">
    
    
    <link rel="stylesheet" href="<?php echo e(asset("css/app.css")); ?>">
    

</head>
<body>
    <section id="dashboard">
        <vue-progress-bar></vue-progress-bar>
        <header>
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <!-- Container wrapper -->
                <div class="container">
                <!-- Toggle button -->
                <button class="navbar-toggler" type="button" data-mdb-toggle="collapse" data-mdb-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false"
                    aria-label="Toggle navigation"> <i class="fas fa-bars"></i></button>
            
                <!-- Collapsible wrapper -->
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Navbar brand -->
                    <a class="navbar-brand mt-2 mt-lg-0" href="#">
                        <img src="<?php echo e(asset('/images/logo.png')); ?>" height="20" alt="MDB Logo" loading="lazy"/>
                    </a>
                    <!-- Left links -->
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <router-link :to="{name: 'dashboard'}" class="nav-link ripple">الرئيسية</router-link>
                        </li>
                        <li class="nav-item">
                            <router-link :to="{name: 'create-invoice'}" class="nav-link ripple"> أنشاء طلب</router-link>
                        </li>
                        <li class="nav-item">
                            <router-link :to="{name: 'invoice-list'}" class="nav-link ripple"> قائمة الطلبات</router-link>
                        </li>
                        <li class="nav-item">
                            <router-link :to="{name: 'invoice-list-padding'}" class="nav-link ripple">  قائمة الطلبات جاري الشحن  </router-link>
                        </li>
                        <li class="nav-item">
                            <router-link :to="{name: 'invoice-list-complate'}" class="nav-link ripple"> قائمة الطلبات الواصل تم</router-link>
                        </li>
                        <li class="nav-item">
                            <router-link :to="{name: 'invoice-list-cancel'}" class="nav-link ripple">   قائمة طلبات الراجع</router-link>
                        </li>
                        <?php if(auth()->user()->role=='super'): ?>
                        <li class="nav-item">
                            <router-link :to="{name: 'user.list'}" class="nav-link ripple">مجموع الموضفين</router-link>
                        </li>
                        <?php endif; ?>
                    </ul>
                    <!-- Left links -->
                </div>
                <!-- Collapsible wrapper -->
            
                <!-- Right elements -->
                <div class="d-flex align-items-center">
            
                    <button v-cloak @click="showSidebar2=true" v-if="editinvoiceQuee.length > 0" class="btn btn-sm btn-warning me-5">تعديل ({{ editinvoiceQuee.length }})</button>
                    <button v-cloak @click="showSidebar=true" v-if="printQuee.length > 0" class="btn btn-sm btn-warning me-5">طبع ({{ printQuee.length }})</button>
                    <!-- Notifications -->
                    <!-- Avatar -->
                    <h5 class="me-2"><strong><?php echo e(auth()->user()->name); ?></strong></h5>
                    <div class="dropdown">
                        <a
                            class="dropdown-toggle d-flex align-items-center hidden-arrow"
                            href="#"
                            id="navbarDropdownMenuAvatar"
                            role="button"
                            data-mdb-toggle="dropdown"
                            aria-expanded="false"
                        >
                            <img
                            src="/images/logo.png"
                            class="rounded-circle"
                            height="10"
                            alt="Black and White Portrait of a Man"
                            loading="lazy"
                            />
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdownMenuAvatar">
                            <li>
                                <router-link :to="{name: 'my-profile'}" class="dropdown-item">حسابي <i class="fas fa-user"></i></router-link>
                            </li>
                            <?php if(auth()->user()->role == "super"): ?>
                            <li>
                                <router-link :to="{name: 'user.list'}" class="dropdown-item">جميع المستخدمين <i class="fas fa-user-group"></i></router-link>
                            </li>    
                            <?php endif; ?>
                            
                            
                            <li>
                                <a onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();" class="dropdown-item text-danger" href="#">تسجيل خروج</a>
                            </li>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </ul>
                    </div>
                </div>
                <!-- Right elements -->
                </div>
                <!-- Container wrapper -->
            </nav>
            <!-- Navbar -->
        </header>
        <div class="header2 mt-3">
            <h5 v-cloak><i class="fas fa-shopping-cart"></i> &nbsp; عدد المنتجات : <span class="text-success">{{ settingData.product_stock }}</span></h5>
            <h5 v-cloak><i class="fa fa-free-code-camp"></i> &nbsp; السعر الإجمالي للمنتج : <span class="text-success">{{ settingData.total_price }} IQD</span></h5>
        </div>

        <section class="content">
            <?php echo $__env->yieldContent("content"); ?>
        </section>

        
        <div class="sidebar-overlay" :class="{'show' : showSidebar}" v-if="printQuee.length > 0">
            <div class="sidebar">
                <div class="sidebar-head">
                    <button @click="printQuee=false" class="close-btn ripple"><i class="fas fa-times"></i></button>
                    <h6>PRINT JOB - <span>{{ printQuee.length }} invoices</span></h6>
                </div>
                <div class="sidebar-body">
                    <ul class="list-group list-group-light">
                        <li v-for="(quee,i) in printQuee" :key="i" class="list-group-item px-3 border-0 active mb-1" aria-current="true">
                          <b>{{ i+1 }} - </b><span class="badge badge-warning">#{{ quee }}</span>
                        </li>
                    </ul>
                </div>
                
                <div style="display: flex; gap: 10px;">
                     <button @click="sendviapi" class="btn btn-success">ارسال الى شركة شحن</button> 
                     <button @click="printInvoice" class="btn btn-success">طباعة</button> 
                    <button @click="printInvoiceimages" class="btn btn-success">طباعة مع صور المنتج</button>
                  </div>
                
                <div class="sidebar-footer">
                    <label for="">عدد النسخ</label>
                    <input class="form-control mb-2" type="number" placeholder="عدد النسخ" v-model="printCopy" > 

                </div>

            </div>
        </div>
        <div class="sidebar-overlay" :class="{'show' : showSidebar2}" v-if="editinvoiceQuee.length > 0">
            <div class="sidebar">
                <div class="sidebar-head">
                    <button @click="editinvoiceQuee=false" class="close-btn ripple"><i class="fas fa-times"></i></button>
                    <h6>PRINT JOB - <span>{{ editinvoiceQuee.length }} invoices</span></h6>
                </div>
                <div class="sidebar-body">
                    <ul class="list-group list-group-light">
                        <li v-for="(quee,i) in editinvoiceQuee" :key="i" class="list-group-item px-3 border-0 active mb-1" aria-current="true">
                          <b>{{ i+1 }} - </b><span class="badge badge-warning">#{{ quee }}</span>
                        </li>
                    </ul>
                </div>
                
                <div style="display: flex; gap: 10px;">
                    <button @click="sendviapi" class="btn btn-success">ارسال الى شركة شحن</button> 
                    <button @click="changestatus" class="btn btn-success">تغيير الحالة</button>
                    <button @click="editinvoice" class="btn btn-success">طباعة</button> 
                    <button @click="printInvoiceimages" class="btn btn-success">طباعة مع صور المنتج</button>
                   
                  </div>
                
                <div class="sidebar-footer">
                    <label for="">عدد النسخ</label>
                    <input class="form-control mb-2" type="number" placeholder="عدد النسخ" v-model="printCopy" >

                    <div class="col-md-4 mt-2">
                        <select class="form-select" v-model="status">
                            <option value="">الكل</option>
                            <option value="pending">جاري شحن</option>
                            <option value="completed">واصل تم</option>
                            <option value="canceled">راجع</option>
                            <option value="delayed">مؤجل</option>
                        </select>
                    </div>

                </div>

            </div>
        </div>


    </section>
    <script>
        window.role = "<?php echo e(auth()->user()->role); ?>";
    </script>
    <script>
        function editInvoiceimages() {
          // your code here
          
          window.location.href = '/dashboard/changeStatus/' + string + '/changeto/' + this.status;
        }
      </script>
    
    <script src="https://code.jquery.com/jquery-3.6.3.min.js" integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script>
    <script>
        // window.permission = 
    </script>
    
    <script type="text/javascript" src="<?php echo e(asset("js/app.js")); ?>"></script>
    
</body>
</html><?php /**PATH /home/wholesaleteknoiq/public_html/resources/views/layouts/master.blade.php ENDPATH**/ ?>