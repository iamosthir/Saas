<template>
  <div class="row justify-content-center">
    <div class="col-md-4 text-center">
        <div class="card">
            <div class="card-body">
                <div class="error">
                    <h1 class="text-danger"><i class="fas fa-times-circle"></i></h1>
                    <h2>Access Denied</h2>
                    <p>You do not have permission to view this page.</p>
                    <p>Please check your credentials and try again</p>
                    <p>Error code : 403</p>
                </div>
            </div>
        </div>
    </div>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>