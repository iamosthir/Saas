<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SubscriptionPlansController extends Controller
{
    //
}
